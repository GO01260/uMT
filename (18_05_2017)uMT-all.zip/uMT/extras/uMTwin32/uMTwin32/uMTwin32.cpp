// uMTwin32.cpp : definisce il punto di ingresso dell'applicazione console.
//

#include "stdafx.h"
#include "uMT.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Kernel.Kn_Start();

	return 0;
}

void		uMT::SetupSysTicks() {};
//void		uMT::SwitchStack() {};
StackPtr_t	uMT::NewTask(StackPtr_t TaskStack, StackSize_t	StackSize, void (*TaskStartAddr)(), void (*BadExit)()) {return (NULL);};
void		uMT::ResumeTask(StackPtr_t StackPtr) {};
void		uMT::Suspend() {};
void		Suspend2();
CpuStatusReg_t	uMT::IntLock() {return(0); };
void		uMT::IntUnlock(CpuStatusReg_t Flags) {};
void		uMT::BadExit() {};			// Helper routine
void		uMT::IdleLoop() {};			// Idle routine
StackPtr_t	uMT::GetSP() { return(NULL); };
void		uMT::iKn_FatalError() { while (1) ; };
void		uMT::iKn_FatalError(const __FlashStringHelper *String) {  ; };
Errno_t		uMT::Kn_PrintInternals() { return(E_SUCCESS); };


/////////////// EOF