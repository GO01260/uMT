
// Demo configuration

#define TEST_YIELD_SPEED			1 

/////////// EOF