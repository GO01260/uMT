// Demonstrate easy use of global saved, Flash based strings
// Source: http://forum.arduino.cc/index.php?topic=110307.0



//### Defines for Flash saved Text #############################################
#define FPr(x);   Serial.print(FP(x));              // FlashPrint(FT)
#define FPrL(x);  Serial.println(FP(x));            // FlasPrintLine(FT)
#define SPFT(x);  Serial.print(FP(FT_##x));         // shorter version (ID)
#define SPFTL(x); Serial.println(FP(FT_##x));       // shorter version (ID)

#define SFP(x);   Serial.print(FP(x));

#define FT(x,y);  const char FT_##x[] PROGMEM = {y};// generate FlashText(ID,FT)
#define FP(x)     (__FlashStringHelper*)(x)         // Helper
//******************************************************************************



//### Shortening standard Serial.Print F() #####################################
#define SPr(x);   Serial.print(x);                  // short for Serial.print
#define SPrL(x);  Serial.println(x);                // short for Serial.println
#define SPrF(x);  SPr(F(x));                        // short for F-Macro Serial.print
#define SPrLF(x); SPrL(F(x));                       // short for F-Macro Serial.println
//******************************************************************************



//### Generate global Flash saved strings ######################################
FT(0,"Text 0");                                               // Flash Text FT_0
FT(1,"This is a global saved and Flash "
     "saved Text!");                                          // FT_1
FT(2,"File: " __FILE__ " Date: " __DATE__ " Time: " __TIME__);// FT_2
FT(3,"***************************************************");  // FT_3
FT(B4,"*\t RS232 Menu\t\t\t\t  *");                            // FT_4
FT(5,"###################################################");  // FT_3
//******************************************************************************



//### Typedefs ################################################################
typedef void(*pF)(void);                        // Pointer to void FCN(void)
//*****************************************************************************

//### Struct RS232 Commands ###################################################
struct Commands
{
  //char    cmd1[10];                           // Command 1
  const char cmd1[10] PROGMEM;

  //char    cmd2[10];                           // Command 2
  const char cmd2[10] PROGMEM;
  pF      callback;                           // Callback-FCN
  //String  info;                               // Info on Command
  //char    info[60];
  const char info[60] PROGMEM;
 
};
//*****************************************************************************

#define CMD_CNT (sizeof(CmdAR)/sizeof(CmdAR[0])) // Number of Commands

//### Define RS232-Command-Array ##############################################
Commands CmdAR[] = {
// cmd1,    cmd2,    callback, info
{"TASK",   "t  ",   cTask,   "set Task Parameter (ID, Periode, Set, CNT, Offset)"},
{"Set",    "s  ",   cTask,   "set Task Parameter (ID, Periode, Set, CNT, Offset)"},
{"LCDBL",  "lcdb",  cLcdBL,  "set LCD BackLight (off/Auto-Off Periode)"          }
};


void cTask(){
  SPrLF("cTask");
}

void cLcdBL(){
  SPrLF("cLcdBL");
}

void printComands(){
  SPrL();
  //SPrLF("**************************************************");
  SPFTL(3);
  //SPrLF("*\tRS232 Command List\t\t\t *");
  SPFTL(B4);
  //SPrLF("**************************************************");
  SPFTL(3);
  SPrLF("Cmd1\t, Cmd2\t, Info (Parameter)");
  for(byte i=0; i<CMD_CNT; i++){
    SPrF(" ");
    //SPr(FP(CmdAR[i].cmd1)); SPrF("\t, ");
    SFP(CmdAR[i].cmd1); SPrF("\t, ");
    SFP(CmdAR[i].cmd2); SPrF("\t, ");
    SFP(CmdAR[i].info);
    SPrL();
  }
  SPrL();
  //SPrLF("**************************************************");
  SPFTL(3);
  SPrLF("Type: < Command1/2, Val1, Val2, Val3, Val4, Val5");
  SPrL();
}


//### Setup() #####################################################
void setup() {
  Serial.begin(230400);
  SPrL();
  Serial.println(F("Macro-Based, only single "
                   "In-Function usable Flash saved Text."));
  SPrLF("...the same, but shorter command ");

  SPrL();                   // Newline
 
  FPrL(FT_0);               // Serial Print Line Flash saved Text
  FPrL(FT_1);
  SPFTL(2);                 // Shortest Version SerialPrintFlashText(ID)
  SPFTL(5);
 
 
}//void setup()
//*****************************************************************



//### Main loop() #################################################
void loop(){

  // reuse same string anywere in the Code
  //SPrL();                     // Newline
  //SPFTL(3);                   // Headder, SerialPrintFlashTextLine
  //SPFTL(B4);             
  //SPFTL(3);

  SPrL();
  printComands();

  delay(10000); 
}// void loop()
//*****************************************************************

