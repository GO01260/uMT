
// Demo configuration

#define TEST_TIMERS1			1 

/////////// EOF