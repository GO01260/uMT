
// Demo configuration

#define TEST_SEMAPHORES_TIMERS			1 

/////////// EOF