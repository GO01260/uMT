
// Demo configuration

#define TEST_TASK_RESTART			1 

/////////// EOF