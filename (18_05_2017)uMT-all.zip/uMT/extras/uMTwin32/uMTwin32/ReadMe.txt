﻿========================================================================
    APPLICAZIONE CONSOLE: cenni preliminari sul progetto 
    uMTwin32
========================================================================

La creazione guidata applicazione ha creato questa applicazione 
uMTwin32.

Questo file contiene un riepilogo del contenuto di ciascun file che fa parte
dell'applicazione uMTwin32.


uMTwin32.vcxproj
    File di progetto principale per i progetti VC++ generati tramite una 
    creazione guidata applicazione.
    Contiene informazioni sulla versione di Visual C++ che ha generato il file e
    informazioni sulle piattaforme, le configurazioni e le caratteristiche del 
    progetto selezionate con la Creazione guidata applicazione.

uMTwin32.vcxproj.filters
    File dei filtri per i progetti VC++ generati tramite una Creazione guidata 
    applicazione. 
    Contiene informazioni sull'associazione tra i file del progetto e i filtri. 
    Tale associazione viene utilizzata nell'IDE per la visualizzazione di
    raggruppamenti di file con estensioni simili in un nodo specifico, ad 
    esempio: i file con estensione cpp sono associati al filtro "File di 
    origine".

uMTwin32.cpp
    File di origine principale dell'applicazione.

/////////////////////////////////////////////////////////////////////////////
Altri file standard:

StdAfx.h, StdAfx.cpp
    Tali file vengono utilizzati per compilare un file di intestazione
    precompilato denominato uMTwin32.pch e un file dei tipi 
    precompilato denominato StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Altre note:

La creazione guidata applicazione utilizza i commenti "TODO:" per indicare le
parti del codice sorgente da aggiungere o personalizzare.

/////////////////////////////////////////////////////////////////////////////
