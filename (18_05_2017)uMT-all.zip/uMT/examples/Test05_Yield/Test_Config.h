
// Demo configuration

#define TEST_YIELD			1 

/////////// EOF